# openiti

This is a first attempt to create a Python library that combines all often-used code in the OpenITI project. 
